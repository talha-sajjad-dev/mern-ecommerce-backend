import mongoose, { Schema } from 'mongoose';

const sellerSchema = mongoose.Schema({
    userId: {
        type: Schema.Types.ObjectId,
        ref: 'User',
        required: true,
        index: true,
    },

    storeName: {
        type: String,
        required: true,
    },

    licenseId: {
        type: Number,
        required: true,
    },

    businessType: {
        type: String,
        required: true,
    },

    street: {
        type: String,
        required: true,
    },

    city: {
        type: String,
        required: true,
    },

    state: {
        type: String,
        required: true,
    },

    country: {
        type: String,
        required: true,
    },

    postalCode: {
        type: Number,
    },

    storeDescription: {
        type: String,
    },

    licenseImg: {
        url: {
            type: String,
            default: null,
        },
        publicId: {
            type: String,
            default: null,
        }
    },

    bankAccHolderName: {
        type: String,
        required: true,
    },
    
    bankName: {
        type: String,
        required: true,
    },

    bankAccNum: {
        type: Number,
        required: true,
    },

    cvcNum: {
        type: Number,
        required: true,
    },

    bankAccType: {
        type: String,
        required: true,
    }
});

export default mongoose.model('Seller', sellerSchema);